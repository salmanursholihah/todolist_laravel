<?php

namespace App\Http\Controllers;

use App\Models\Catatan;
use Illuminate\Http\Request;
use App\Exports\CatatanExport;
use Maatwebsite\Excel\Facades\Excel;
use Barryvdh\DomPDF\Facade\Pdf;


class CatatanExportController extends Controller

{
    public function exportExcel()
    {
        return Excel::download(new CatatanExport, 'laporan_catatan.xlsx');
    }

    public function exportPDF()
    {
        $catatans = Catatan::all();
        $pdf = Pdf::loadView('admin.catatans.pdf', compact('catatans'));
        return $pdf->download('laporan_catatan.pdf');
    }
}