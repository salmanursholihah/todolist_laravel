@extends ('layouts.app')

@section ('title', 'content')

@section ('content')
<main class="container">
    <article>
        <p> pengen punya catatan tugas tapi <br>takut ribet dan kapasitas memori kamu tidak cukup??
            <br>
        </p>
        <br><br><br>
        tenang..... my todolist hadir dengan tampilan yang bersih,<br> ringan dan mudah digunkan sehingga anda
        dapat
        <br>langsung
        menambahkan,mengedit,<br>
        serta menyelesaikan tugas anda tanpa ribet. <br> <br><br>selain itu kamu juga tidak perlu takut lupa
        dedline
        atau
        kuwalahan <br>
        dengan banyaknya
        pekerjaan, karena di aplikasi my todolist <br>anda dapat mengatur hanya dengan beberapa klik

</main>
@endsection