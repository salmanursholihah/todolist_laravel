<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>my todo</title>
    <link rel="stylesheet" href="style/style.css" />
</head>

<body>


    <main class="container">
        <article>
            <h2> pengenalan todolist</h2>
            <p class="date">25 April 2025</p>

            <p> hai semuanay yuk kenalan dengan aplikasi
                todolist... <br> aplikasi todolist meerupakan aplikasi sederhana yang dapat membantu pengguna <br>untuk
                mengelola
                dan mencatat tugas harian mereka. </p>
            <img src="https://st3.depositphotos.com/4302113/35204/v/1600/depositphotos_352048986-stock-illustration-checklist-to-do-list-vector.jpg"
                alt="gambar ilustrasi" width="200px"> <br><br>
            <p> nah.... dengan menggunakan aplikasi todolist <br>ada beberapa keuntungan yang bisa kita dapatkan
                <br>1. Meningkatkan Produktivitas <br>
                Dengan daftar tugas yang jelas, kita bisa fokus pada pekerjaan yang <br>penting dan mengurangi waktu
                terbuang. <br>
                <br>
                2. Mengurangi Stres <br>
                Mencatat semua tugas membuat pikiran lebih tenang karena kita tidak <br>perlu mengingat semuanya di
                kepala.
                <br>
                <br>
                3. Membantu Manajemen Waktu <br>
                Tugas-tugas yang terorganisir memudahkan kita mengatur waktu dengan lebih efektif.
                <br>
                <br>
                4. Memberikan Rasa Pencapaian <br>
                Menandai tugas yang selesai memberikan rasa puas dan semangat <br>
                untuk menyelesaikan tugas lainnya.
            </p>
        </article>
    </main>
</body>

</html>